DROP INDEX IdxOnSeller ON Auctions;
DROP INDEX IdxOnBuyPrice ON Auctions;
DROP INDEX IdxOnEndTime ON Auctions;