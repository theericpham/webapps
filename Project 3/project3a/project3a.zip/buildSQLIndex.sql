CREATE INDEX IdxOnSeller ON Auctions(SellerID);
CREATE INDEX IdxOnBuyPrice ON Auctions(BuyPrice);
CREATE INDEX IdxOnEndTime ON Auctions(EndTime);