README

Student 1: Neema Oshidary
SID 1:

Student 2: Eric Pham
SID 2: 303 787 024

Project 3A contains the src files to create a Lucene Index on Item Name, Description, and Categories.
These inverted indices will make keyword searches efficient.  These indices are stored under the path
$LUCENE_INDEX.

We also have provided sql queries to create indices on Item SellerID, BuyPrice, and Endtime as we felt 
these attributes will be the most relevant fields for users to filter results upon.