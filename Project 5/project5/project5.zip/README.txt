Team Member 1: 
Name: Eric Pham
SID: 303-787-024

Team Member 2:
Name: Neema Oshidary
SID: 403-800-317

Q1: For which communication(s) do you use the SSL encryption?
A1: We are using SSL encryption the communication from (4) to (5) and from (5) to (6)
	since the user's credit card information is in transit during this time.

Q2: How do you ensure that the item was purchased exactly at the Buy_Price of that particular item?
A2: We ensure that all item information, including Buy_Price, isn ot compromised by pushing/storing 
	this information into a valid session during the credit-card-information page.  Then in the
	payment-confirmation page, we check that the session is still valid and secure; if so, this
	guarantees that our sensitive information has been left untouched.

Q3:
A3:

Q4:
A4:
	